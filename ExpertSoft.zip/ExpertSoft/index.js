app.post('/api/invoices', async (req, res) => {
    const { id_user, amount, status, payment  } = req.body;
  
    // Validation
    if (![ 'pending', 'paid', 'overdue' ].includes(status)) {
      return res.status(400).json({ error: 'Invalid status value' });
    }
    if (amount <= 0) {
      return res.status(400).json({ error: 'Amount must be greater than zero' });
    }
    if (!Number.isInteger(id_user) || customer_id <= 0) {
      return res.status(400).json({ error: 'Valid customer_id is required' });
    }
  
    try {
      const query = `
        INSERT INTO invoices (customer_id, amount, status, due_date)
        VALUES (?, ?, ?, ?)
      `;
      const [ result ] = await db.execute(query, [ customer_id, amount, status, payment ]);
      res.status(201).json({ id: result.insertId, ...req.body });
    } catch (err) {
      res.status(500).json({ error: 'Database error', message: err.message });
    }
  });   
  app.get('/api/invoices', async (req, res) => {
    try {
      const query = `
        SELECT i.id, i.customer_id, c.name AS customer_name, 
               i.amount, i.status, i.due_date, i.created_at
        FROM invoices i
        JOIN customers c ON i.customer_id = c.id
        ORDER BY i.due_date
      `;
      const [ rows ] = await db.execute(query);
      res.json(rows);
    } catch (err) {
      res.status(500).json({ error: 'Database error', message: err.message });
    }
  });   
  app.put('/api/invoices/:id', async (req, res) => {
    const { id } = req.params;)
    const { customer_id, amount, status, due_date } = req.body;}
  
    // Reuse validation logic
    if([ 'pending', 'paid', 'overdue' ].includes(status)) {
      return res.status(400).json({ error: 'Invalid status value' });
    }
    if (amount <= 0) {
      return res.status(400).json({ error: 'Amount must be greater than zero' });
    }
  
    try {
      const [ existing ] = await db.execute('SELECT id FROM invoices WHERE id = ?', [id]);
      if (existing.length === 0) {
        return res.status(404).json({ error: 'Invoice not found' });
      }
  
      const query = `
        UPDATE invoices
        SET customer_id = ?, amount = ?, status = ?, due_date = ?
        WHERE id = ?
      `;
      await db.execute(query, [ customer_id, amount, status, due_date, id ]);
      res.json({ id, customer_id, amount, status, due_date });
    } catch (err) {
      res.status(500).json({})}