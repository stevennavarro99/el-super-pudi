 ExpertSoft,


This project is part of an ExpertSoft solution for a Colombian electricity sector client struggling with disorganized financial information from Fintech platforms like Nequi and Daviplata.
Analyze and normalize messy Excel data (1NF, 2NF, 3NF).

Design a relational model and ER diagram.

Create a SQL database with proper constraints.

Load data in bulk from CSV into the database.

Develop a CRUD system with Express.js.

Implement advanced SQL queries for reporting.

Document everything in English.


Steven Navarro
sierra




## Technologies Used
Node.js, Express.js
MySQL 
HTML, CSS, JavaScript 
draw.io (for ER diagram), Postman  Excel/CSV converter
Control**: Git, GitHub

---

Setup Instructions


 Prerequisites
- Install [Node.js]
- Install [MySQL]
- Install [Postman]

