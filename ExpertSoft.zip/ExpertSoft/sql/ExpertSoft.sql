create table users(
id_user int auto_increment primary key,
full_name varchar(100) not null unique,
identification varchar(100) not null unique,
direction varchar(100) not null unique,
cell varchar(100) not null unique,
email varchar(100) not null
);
create table payment_platform(
id_platform  varchar(100) primary key,
Platform_payment_metod varchar(50) not null,
invoice_number varchar(100) not null,
billing_period int,
billing_amount int,
payment_amount int,
id_user int,
foreign key(id_user) references users(id_user) on delete cascade
);
create table day_time_transaction(
id_day_time_transaction int auto_increment primary key,
amount int not null,
transaction_status varchar(100) not null unique,
transaction_type varchar(100) not null,
id_platform varchar(100),
foreign key(id_platform) references payment_platform(id_platform)
);

